import { createDeleteHandler } from '../delete-account/handler.mjs';

const reply = (status, body) => new Response(JSON.stringify(body), {
  status, headers: { 'Content-Type': 'application/json' },
});
const checked = (result) => {
  if (result.error) throw new Error('cleanup_database_failed');
  return result.data;
};

// This adapter is private to the worker. It grants no HTTP user impersonation:
// only a UID atomically authorized/frozen by claim_guest_cleanup reaches it.
// Reuse the exact existing deletion handler, including paging, Storage removal,
// Auth deletion and FK cascades, without altering its public session contract.
async function deleteClaimedGuest(admin, url, uid) {
  const internalAdmin = {
    rpc: (...args) => admin.rpc(...args),
    storage: admin.storage,
    auth: {
      admin: admin.auth.admin,
      getClaims: async () => ({ data: { claims: { sub: uid, role: 'authenticated', iss: `${url}/auth/v1` } } }),
      getUser: async () => admin.auth.admin.getUserById(uid),
    },
  };
  return createDeleteHandler(() => internalAdmin, url)(new Request(url, {
    method: 'POST', headers: { Authorization: 'Bearer internal-cleanup' },
    body: JSON.stringify({ confirm: 'DELETE' }),
  }));
}

export const createCleanupHandler = (createAdmin, url, secret) => async (request) => {
  if (request.method !== 'POST') return reply(405, { error: 'method_not_allowed' });
  if (!secret || secret.length < 32 || request.headers.get('x-cleanup-secret') !== secret) {
    return reply(401, { error: 'unauthorized' });
  }
  try {
    const admin = createAdmin();
    const settings = checked(await admin.from('guest_cleanup_settings').select('*').single());
    if (!settings.enabled) return reply(200, { enabled: false });
    const candidates = checked(await admin.rpc('preview_guest_cleanup')
      .order('eligible_at').order('user_id').limit(settings.batch_size));
    if (settings.dry_run) {
      console.log(JSON.stringify({ event: 'guest_cleanup_dry_run', candidates }));
      return reply(200, { dry_run: true, candidates });
    }
    const pending = checked(await admin.from('guest_cleanup_log').select('user_id')
      .is('deleted_at', null).order('attempted_at').limit(settings.batch_size));
    const ids = [...new Set([...pending, ...candidates].map((row) => row.user_id))].slice(0, settings.batch_size);
    const results = [];
    const started = Date.now();
    for (const uid of ids) {
      if (Date.now() - started > 120000) break;
      if (!checked(await admin.rpc('claim_guest_cleanup', { p_user_id: uid }))) continue;
      const response = await deleteClaimedGuest(admin, url, uid);
      const result = await response.json();
      if (!result.deleted) {
        checked(await admin.from('guest_cleanup_log').update({ last_error: result.error ?? 'retry_required' })
          .eq('user_id', uid).is('deleted_at', null));
      }
      results.push({ user_id: uid, ...result });
    }
    console.log(JSON.stringify({ event: 'guest_cleanup', results }));
    return reply(results.some((r) => r.error) ? 500 : 200, { results });
  } catch {
    console.error('guest_cleanup_failed');
    return reply(500, { error: 'guest_cleanup_failed' });
  }
};
